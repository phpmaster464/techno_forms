<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head></head>
    <body>
        Hello <p>{!! $name !!}</p> your password is : <p>{!! $pass !!}</p> , kindly login to <a href="103.101.59.95/dev_techno_forms/public/login">Techno Forms</a>
    </body>
</html>