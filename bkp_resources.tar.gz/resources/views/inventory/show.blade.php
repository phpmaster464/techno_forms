@extends('layouts.app')
@section('content')
Job show page
@endsection